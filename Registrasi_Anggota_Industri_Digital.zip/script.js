document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("registrationForm");
  const dataTableBody = document.querySelector("#dataTable tbody");
  const majorSelect = document.getElementById("major");
  const otherMajorInput = document.getElementById("otherMajor");
  const editIndexInput = document.getElementById("editIndex");
  const clearBtn = document.getElementById("clearBtn");

  const predefinedMajors = Array.from(majorSelect.options)
    .filter((option) => option.value !== "" && option.value !== "Lainnya")
    .map((option) => option.value);

  // 2. Event Listener untuk Pilihan Jurusan
  majorSelect.addEventListener("change", () => {
    otherMajorInput.classList.toggle("hidden", majorSelect.value !== "Lainnya");
    if (majorSelect.value !== "Lainnya") {
      otherMajorInput.value = "";
    }
  });

  // --- FUNGSI UTILITY & VALIDASI ---
  function getValue(id) {
    const element = document.getElementById(id);
    return element ? element.value.trim() : "";
  }

  function setError(id, message) {
    const element = document.getElementById(id);
    if (element) {
      element.innerText = message;
    }
  }

  function clearErrors() {
    document.querySelectorAll(".error").forEach((el) => (el.innerText = ""));
  }

  function validateEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  function validatePassword(password) {
    return /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/.test(password);
  }

  function validatePhone(phone) {
    return /^08[0-9]{8,11}$/.test(phone);
  }
  // --- AKHIR FUNGSI UTILITY & VALIDASI ---

  // 3. Event Listener untuk Submit Form
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    clearErrors();

    const name = getValue("name");
    const email = getValue("email");
    const password = getValue("password");
    const confirmPassword = getValue("confirmPassword");
    let major = getValue("major");
    const otherMajor = getValue("otherMajor");
    const phone = getValue("phone");
    const editIndex = getValue("editIndex");

    let valid = true;

    // Validasi
    if (name === "") {
      setError("nameError", "Nama tidak boleh kosong");
      valid = false;
    }
    if (!validateEmail(email)) {
      setError("emailError", "Format email tidak valid");
      valid = false;
    }
    if (!validatePassword(password)) {
      setError(
        "passwordError",
        "Password minimal 8 karakter, kombinasi huruf & angka"
      );
      valid = false;
    }

    if (confirmPassword !== password || password === "") {
      setError("confirmPasswordError", "Konfirmasi password tidak sama");
      valid = false;
    }

    if (major === "") {
      setError("majorError", "Pilih jurusan terlebih dahulu");
      valid = false;
    }

    if (major === "Lainnya" && otherMajor === "") {
      setError("majorError", "Isi jurusan lainnya");
      valid = false;
    }

    if (!validatePhone(phone)) {
      setError("phoneError", "Nomor HP harus diawali 08 dan hanya angka");
      valid = false;
    }

    if (!valid) return;

    const finalMajor = major === "Lainnya" ? otherMajor : major;

    const newData = { name, email, password, major: finalMajor, phone };
    let data = JSON.parse(localStorage.getItem("students")) || [];

    // Logika Edit atau Tambah Baru
    if (editIndex === "") {
      data.push(newData);
      alert("Data telah ditambahkan!"); // ✅ ALERT
    } else {
      const index = parseInt(editIndex);
      if (!isNaN(index) && index >= 0 && index < data.length) {
        data[index] = newData;
        alert("Data telah diperbarui!"); // ✅ ALERT
      }
      editIndexInput.value = "";
    }

    localStorage.setItem("students", JSON.stringify(data));
    form.reset();
    otherMajorInput.classList.add("hidden");
    loadData();
  });

  // 4. Tombol "Hapus Semua" (Reset Form)
  clearBtn.addEventListener("click", () => {
    form.reset();
    otherMajorInput.classList.add("hidden");
    alert("Formulir telah dihapus!"); // ✅ ALERT
  });

  // 5. Fungsi untuk Memuat dan Menampilkan Data ke Tabel
  function loadData() {
    const data = JSON.parse(localStorage.getItem("students")) || [];
    dataTableBody.innerHTML = "";

    data.forEach((item, index) => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.email}</td>
        <td>${item.major}</td> 
        <td>${item.phone}</td>
        <td>
            <button class="action-btn" onclick="editData(${index})">Edit</button>
            <button class="action-btn delete" onclick="deleteData(${index})">Hapus</button>
        </td>
      `;
      dataTableBody.appendChild(row);
    });
  }

  loadData();

  // 6. Fungsi Global (Edit dan Hapus)
  window.editData = function (index) {
    const data = JSON.parse(localStorage.getItem("students")) || [];
    const item = data[index];

    document.getElementById("name").value = item.name;
    document.getElementById("email").value = item.email;
    document.getElementById("password").value = item.password;
    document.getElementById("confirmPassword").value = item.password;
    document.getElementById("phone").value = item.phone;
    document.getElementById("editIndex").value = index;

    if (predefinedMajors.includes(item.major)) {
      majorSelect.value = item.major;
      otherMajorInput.value = "";
      otherMajorInput.classList.add("hidden");
    } else {
      majorSelect.value = "Lainnya";
      otherMajorInput.value = item.major;
      otherMajorInput.classList.remove("hidden");
    }
  };

  window.deleteData = function (index) {
    const data = JSON.parse(localStorage.getItem("students")) || [];
    if (confirm(`Yakin ingin menghapus data ${data[index].name}?`)) {
      data.splice(index, 1);
      localStorage.setItem("students", JSON.stringify(data));
      loadData();
      alert("🗑️ Data telah dihapus!"); // ✅ ALERT
    }
  };
});
